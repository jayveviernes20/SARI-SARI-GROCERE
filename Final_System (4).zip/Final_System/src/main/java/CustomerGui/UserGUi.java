     /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package CustomerGui;
import javax.swing.JOptionPane;
import maincode.SystemRunner;
import javax.swing.JButton;
import java.util.ArrayList;
import CustomerGui.PaymentGui;
import data.ItemDAO;
/**
 *
 * @author Chris Adrian Gianan
 */
public class UserGUi extends javax.swing.JFrame {
    private ArrayList<String> currentOrder = new ArrayList<>();
private void reserveItem(String item) {

    String size = "";

    if (item.equals("Lumpia wrapper")) {

    ArrayList<String> prices =
            data.ItemDAO.getPrices(item);

    if (prices == null || prices.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "No available sizes for Lumpia wrapper.",
                "ERROR",
                JOptionPane.ERROR_MESSAGE
        );

        return;
    }

    String[] sizes =
            new String[prices.size()];

    for (int i = 0; i < prices.size(); i++) {

        String[] priceData =
                prices.get(i).split("\\|");

        if (priceData.length >= 2) {

            String variant =
                    priceData[0].trim();

            double price;

            try {
                price =
                        Double.parseDouble(
                                priceData[1].trim()
                        );
            } catch (NumberFormatException e) {
                price = 0;
            }

            sizes[i] =
                    variant
                    + " - ₱"
                    + String.format(
                            "%.2f",
                            price
                    );

        } else {

            sizes[i] =
                    prices.get(i);
        }
    }

    int choice =
            JOptionPane.showOptionDialog(
                    this,
                    "Choose size:",
                    "Lumpia Wrapper",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    sizes,
                    sizes[0]
            );

    if (choice == -1) {
        return;
    }

    String selected =
            prices.get(choice);

    String[] selectedData =
            selected.split("\\|");

    if (selectedData.length >= 1) {
        size = selectedData[0].trim();
    }
}

    String quantity = JOptionPane.showInputDialog(
            this,
            "Enter quantity for " + item + ":"
    );

    if (quantity == null || quantity.trim().isEmpty()) {
        return;
    }

    int qty;

    try {
        qty = Integer.parseInt(quantity.trim());
    } catch (Exception e) {

        JOptionPane.showMessageDialog(
                this,
                "Please enter numbers only!"
        );

        return;
    }

    if (qty <= 0) {

        JOptionPane.showMessageDialog(
                this,
                "Quantity must be greater than 0!"
        );

        return;
    }

    if (size.isEmpty()) {

        currentOrder.add(
                item + " | " + qty
        );

    } else {

        currentOrder.add(
                item + " - " + size + " | " + qty
        );
    }

    JOptionPane.showMessageDialog(
            this,
            item + " added to your order!"
    );
}
    private String userName;
    /**
     * Creates new form UserGUi
     */
    public UserGUi() {
    initComponents();
}
    public UserGUi(String name) {
        
        initComponents();
        setLocationRelativeTo(null);

       userName=name;
        lblWelcome.setText("Welcome, " + name + "!");
        loadItems();
    }
private void loadItems() {

    pnlItems.removeAll();

    for (String item : data.ItemDAO.getItems()) {

        String buttonText = item;

        ArrayList<String> prices =
                data.ItemDAO.getPrices(item);

        if (!prices.isEmpty()) {

            String priceText = "";

            for (String priceData : prices) {

                String[] data =
                        priceData.split("\\|");

                if (data.length >= 2) {

                    double price =
                            Double.parseDouble(data[1]);

                    if (!priceText.isEmpty()) {
                        priceText += " / ";
                    }

                    priceText +=
                            "\u20B1"
                            + String.format("%.0f", price);
                }
            }

            buttonText =
                    "<html><center>"
                    + item
                    + "<br>"
                    + "<font size='4'>"
                    + priceText
                    + "</font>"
                    + "</center></html>";
        }

        JButton button =
                new JButton(buttonText);

        button.setFont(
                new java.awt.Font("Segoe UI", 1, 24)
        );

        button.addActionListener(
                e -> reserveItem(item)
        );

        pnlItems.add(button);
    }

    pnlItems.setLayout(
            new java.awt.GridLayout(0, 2, 10, 10)
    );

    pnlItems.revalidate();
    pnlItems.repaint();
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        btnReservation = new javax.swing.JButton();
        btnLogout = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        lblTitle2 = new javax.swing.JLabel();
        lblTitle3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        pnlItems = new javax.swing.JPanel();
        btnItem1 = new javax.swing.JButton();
        btnItem2 = new javax.swing.JButton();
        btnItem5 = new javax.swing.JButton();
        btnItem3 = new javax.swing.JButton();
        btnItem4 = new javax.swing.JButton();
        btnItem6 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        lblWelcome = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        btnNeedHelp = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        btnReserveOrder = new javax.swing.JButton();
        btnAboutUs = new javax.swing.JButton();
        btnReservations = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1380, 790));
        setSize(new java.awt.Dimension(800, 768));

        jPanel2.setBackground(new java.awt.Color(76, 175, 80));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnReservation.setBackground(new java.awt.Color(11, 93, 30));
        btnReservation.setFont(new java.awt.Font("Segoe UI Historic", 1, 20)); // NOI18N
        btnReservation.setForeground(new java.awt.Color(217, 242, 196));
        btnReservation.setText("MY ORDER");
        btnReservation.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(217, 242, 196), 3, true));
        btnReservation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReservationActionPerformed(evt);
            }
        });
        jPanel2.add(btnReservation, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 660, 450, 90));

        btnLogout.setBackground(new java.awt.Color(128, 45, 65));
        btnLogout.setFont(new java.awt.Font("Segoe UI Symbol", 1, 14)); // NOI18N
        btnLogout.setForeground(new java.awt.Color(255, 255, 255));
        btnLogout.setText("↪️LOGOUT");
        btnLogout.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(90, 25, 40), 3, true));
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });
        jPanel2.add(btnLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 20, 160, 50));

        jPanel3.setBackground(new java.awt.Color(217, 242, 196));
        jPanel3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(5, 78, 5), 8, true));
        jPanel3.setLayout(null);

        lblTitle2.setBackground(new java.awt.Color(11, 93, 30));
        lblTitle2.setFont(new java.awt.Font("Comic Sans MS", 1, 30)); // NOI18N
        lblTitle2.setForeground(new java.awt.Color(11, 93, 30));
        lblTitle2.setText("        ====FRESH PRODUCTS====");
        jPanel3.add(lblTitle2);
        lblTitle2.setBounds(10, 60, 640, 38);

        lblTitle3.setBackground(new java.awt.Color(11, 93, 30));
        lblTitle3.setFont(new java.awt.Font("Segoe UI Black", 1, 36)); // NOI18N
        lblTitle3.setForeground(new java.awt.Color(11, 93, 30));
        lblTitle3.setText("SARI SARI GROCER");
        jPanel3.add(lblTitle3);
        lblTitle3.setBounds(150, 20, 380, 38);

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 10, 650, 110));

        jPanel4.setBackground(new java.awt.Color(217, 242, 196));
        jPanel4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(5, 78, 5), 9, true));
        jPanel4.setLayout(null);

        pnlItems.setBackground(new java.awt.Color(204, 204, 204));
        pnlItems.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        pnlItems.setRequestFocusEnabled(false);

        btnItem1.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        btnItem1.setText("Lumpia wrapper");
        btnItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnItem1ActionPerformed(evt);
            }
        });
        pnlItems.add(btnItem1);

        btnItem2.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        btnItem2.setText("Patatasan");
        btnItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnItem2ActionPerformed(evt);
            }
        });
        pnlItems.add(btnItem2);

        btnItem5.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        btnItem5.setText("Pakbit");
        btnItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnItem5ActionPerformed(evt);
            }
        });
        pnlItems.add(btnItem5);

        btnItem3.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        btnItem3.setText("Tawgi");
        btnItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnItem3ActionPerformed(evt);
            }
        });
        pnlItems.add(btnItem3);

        btnItem4.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        btnItem4.setText("Sari Sari");
        btnItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnItem4ActionPerformed(evt);
            }
        });
        pnlItems.add(btnItem4);

        btnItem6.setFont(new java.awt.Font("Dubai", 1, 24)); // NOI18N
        btnItem6.setText("Pinansitan");
        btnItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnItem6ActionPerformed(evt);
            }
        });
        pnlItems.add(btnItem6);

        jPanel4.add(pnlItems);
        pnlItems.setBounds(100, 20, 700, 440);

        jPanel1.setBackground(new java.awt.Color(217, 242, 196));
        jPanel1.setLayout(null);

        lblWelcome.setBackground(new java.awt.Color(11, 93, 30));
        lblWelcome.setFont(new java.awt.Font("Comic Sans MS", 3, 24)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(11, 93, 30));
        lblWelcome.setText("Welcome!");
        jPanel1.add(lblWelcome);
        lblWelcome.setBounds(10, 20, 140, 40);

        jLabel1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(11, 93, 30));
        jLabel1.setText("---------------------------");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(120, 40, 190, 20);

        jPanel4.add(jPanel1);
        jPanel1.setBounds(-270, -280, 340, 60);

        btnNeedHelp.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        btnNeedHelp.setForeground(new java.awt.Color(204, 0, 0));
        btnNeedHelp.setText("❓");
        btnNeedHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNeedHelpActionPerformed(evt);
            }
        });
        jPanel4.add(btnNeedHelp);
        btnNeedHelp.setBounds(820, 20, 50, 40);

        jLabel2.setFont(new java.awt.Font("Nirmala UI", 1, 12)); // NOI18N
        jLabel2.setText("    NEED HELP?");
        jPanel4.add(jLabel2);
        jLabel2.setBounds(800, 60, 80, 30);

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, 910, 490));

        btnReserveOrder.setBackground(new java.awt.Color(11, 93, 30));
        btnReserveOrder.setFont(new java.awt.Font("Segoe UI Historic", 1, 20)); // NOI18N
        btnReserveOrder.setForeground(new java.awt.Color(217, 242, 196));
        btnReserveOrder.setText("RESERVE ORDER ");
        btnReserveOrder.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(217, 242, 196), 3, true));
        btnReserveOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReserveOrderActionPerformed(evt);
            }
        });
        jPanel2.add(btnReserveOrder, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 660, 470, 90));

        btnAboutUs.setText("About us");
        btnAboutUs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAboutUsActionPerformed(evt);
            }
        });
        jPanel2.add(btnAboutUs, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 80, 140, 30));

        btnReservations.setBackground(new java.awt.Color(11, 93, 30));
        btnReservations.setFont(new java.awt.Font("Segoe UI Historic", 1, 20)); // NOI18N
        btnReservations.setForeground(new java.awt.Color(217, 242, 196));
        btnReservations.setText("MY RESERVATIONS");
        btnReservations.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(217, 242, 196), 3, true));
        btnReservations.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReservationsActionPerformed(evt);
            }
        });
        jPanel2.add(btnReservations, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 660, 450, 90));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 1380, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 790, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
       int choice = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to log out?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
    );

    if (choice == JOptionPane.YES_OPTION) {

        new LoginGui().setVisible(true);

        this.dispose();
    } // TODO add your handling code here:
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnReservationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReservationActionPerformed
          if (currentOrder == null || currentOrder.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "Your order is empty!"
        );
        return;
    }

    while (true) {

        // =========================
        // BUILD CURRENT ORDER DISPLAY
        // =========================

        String order = "";
        double total = 0;

        for (String item : currentOrder) {

            if (item == null || !item.contains("|")) {
                JOptionPane.showMessageDialog(
                        this,
                        "Invalid order item!"
                );
                return;
            }

            String[] data = item.split("\\|");

            if (data.length < 2) {
                JOptionPane.showMessageDialog(
                        this,
                        "Invalid order format!"
                );
                return;
            }

            String itemText = data[0].trim();

            int quantity;

            try {
                quantity = Integer.parseInt(data[1].trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(
                        this,
                        "Invalid quantity!"
                );
                return;
            }

            String itemName = itemText;
            String variantName = null;

            if (itemText.contains(" - ")) {

                int separator =
                        itemText.lastIndexOf(" - ");

                itemName =
                        itemText.substring(
                                0,
                                separator
                        ).trim();

                variantName =
                        itemText.substring(
                                separator + 3
                        ).trim();
            }

            double price =
                    ItemDAO.getPrice(
                            itemName,
                            variantName
                    );

            if (price <= 0) {
                JOptionPane.showMessageDialog(
                        this,
                        "Price not found for:\n"
                        + itemText
                );
                return;
            }

            double subtotal =
                    price * quantity;

            total += subtotal;

            order +=
                    itemText
                    + " x"
                    + quantity
                    + " = ₱"
                    + String.format(
                            "%.2f",
                            subtotal
                    )
                    + "\n";
        }

        // =========================
        // FIRST POPUP = VIEW ORDER
        // =========================

        String[] menu = {
            "Edit Quantity",
            "Remove Item",
            "Done"
        };

        int action = JOptionPane.showOptionDialog(
                this,
                "MY ORDER\n\n"
                + order
                + "\nTOTAL = ₱"
                + String.format("%.2f", total)
                + "\n\nWhat would you like to do?",
                "MY ORDER",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                menu,
                menu[2]
        );

        // DONE / CLOSE
        if (action == 2 || action == -1) {
            break;
        }

        // =========================
        // EDIT QUANTITY
        // =========================

        if (action == 0) {

            String[] orderChoices =
                    currentOrder.toArray(
                            new String[0]
                    );

            Object selected =
                    JOptionPane.showInputDialog(
                            this,
                            "Select an item to edit:",
                            "EDIT QUANTITY",
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            orderChoices,
                            orderChoices[0]
                    );

            if (selected == null) {
                continue;
            }

            int index = -1;

            for (int i = 0;
                    i < currentOrder.size();
                    i++) {

                if (currentOrder.get(i).equals(
                        selected.toString())) {

                    index = i;
                    break;
                }
            }

            if (index == -1) {
                continue;
            }

            String selectedItem =
                    currentOrder.get(index);

            String[] data =
                    selectedItem.split("\\|");

            String itemText =
                    data[0].trim();

            int oldQuantity;

            try {

                oldQuantity =
                        Integer.parseInt(
                                data[1].trim()
                        );

            } catch (NumberFormatException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Invalid quantity!"
                );
                continue;
            }

            String newQuantity =
                    JOptionPane.showInputDialog(
                            this,
                            "Enter new quantity for:\n"
                            + itemText
                            + "\n\nCurrent quantity: "
                            + oldQuantity,
                            oldQuantity
                    );

            if (newQuantity == null) {
                continue;
            }

            int quantity;

            try {

                quantity =
                        Integer.parseInt(
                                newQuantity.trim()
                        );

            } catch (NumberFormatException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please enter numbers only!"
                );
                continue;
            }

            if (quantity <= 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Quantity must be greater than 0!"
                );
                continue;
            }

            currentOrder.set(
                    index,
                    itemText + " | " + quantity
            );

            JOptionPane.showMessageDialog(
                    this,
                    "Quantity updated successfully!"
            );
        }

        // =========================
        // REMOVE ITEM
        // =========================

        else if (action == 1) {

            String[] orderChoices =
                    currentOrder.toArray(
                            new String[0]
                    );

            Object selected =
                    JOptionPane.showInputDialog(
                            this,
                            "Select an item to remove:",
                            "REMOVE ITEM",
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            orderChoices,
                            orderChoices[0]
                    );

            if (selected == null) {
                continue;
            }

            int index = -1;

            for (int i = 0;
                    i < currentOrder.size();
                    i++) {

                if (currentOrder.get(i).equals(
                        selected.toString())) {

                    index = i;
                    break;
                }
            }

            if (index == -1) {
                continue;
            }

            int confirm =
                    JOptionPane.showConfirmDialog(
                            this,
                            "Are you sure you want to remove:\n\n"
                            + selected.toString()
                            + "?",
                            "REMOVE ITEM",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE
                    );

            if (confirm ==
                    JOptionPane.YES_OPTION) {

                currentOrder.remove(index);

                JOptionPane.showMessageDialog(
                        this,
                        "Item removed successfully!"
                );
            }

            if (currentOrder.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Your order is now empty."
                );

                break;
            }
        }
    }

// TODO add your handling code here:
    }//GEN-LAST:event_btnReservationActionPerformed

    private void btnItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnItem6ActionPerformed
               // TODO add your handling code here:
    }//GEN-LAST:event_btnItem6ActionPerformed

    private void btnItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnItem4ActionPerformed
               // TODO add your handling code here:
    }//GEN-LAST:event_btnItem4ActionPerformed

    private void btnItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnItem3ActionPerformed
             // TODO add your handling code here:
    }//GEN-LAST:event_btnItem3ActionPerformed

    private void btnItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnItem5ActionPerformed
              // TODO add your handling code here:
    }//GEN-LAST:event_btnItem5ActionPerformed

    private void btnItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnItem2ActionPerformed

              // TODO add your handling code here:
    }//GEN-LAST:event_btnItem2ActionPerformed

    private void btnItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnItem1ActionPerformed

          // TODO add your handling code here:
    }//GEN-LAST:event_btnItem1ActionPerformed

    private void btnReserveOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReserveOrderActionPerformed
      
    // VALIDATION: order must not be empty
    if (currentOrder.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "Your order is empty!"
        );

        return;
    }

    String dateText = JOptionPane.showInputDialog(
            this,
            "Enter reservation date (YYYY-MM-DD):"
    );

    // VALIDATION: user cancelled
    if (dateText == null) {
        return;
    }

    dateText = dateText.trim();

    // VALIDATION: date cannot be empty
    if (dateText.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "Please enter a reservation date!"
        );

        return;
    }

    java.sql.Date reservationDate;

    try {

        reservationDate =
                java.sql.Date.valueOf(dateText);

    } catch (IllegalArgumentException e) {

        JOptionPane.showMessageDialog(
                this,
                "Invalid date!\nUse YYYY-MM-DD."
        );

        return;
    }

    // VALIDATION: must be tomorrow or later
    java.sql.Date tomorrow =
            java.sql.Date.valueOf(
                    java.time.LocalDate.now().plusDays(1)
            );

    if (reservationDate.before(tomorrow)) {

        JOptionPane.showMessageDialog(
                this,
                "Reservation date must be tomorrow or later!"
        );

        return;
    }

    // Send data to PaymentGui
    // Get logged-in user's ID
int userId = data.UserDAO.getUserId(userName);

// VALIDATION: user must exist in MySQL
if (userId <= 0) {

    JOptionPane.showMessageDialog(
            this,
            "User account not found!"
    );

    return;
}

// Get today's date
java.sql.Date orderDate =
        java.sql.Date.valueOf(
                java.time.LocalDate.now()
        );

// Save reservation to MySQL
int reservationId =
        data.ReservationDAO.createReservation(
                userId,
                orderDate,
                reservationDate
        );

// VALIDATION: reservation must be saved successfully
if (reservationId <= 0) {

    JOptionPane.showMessageDialog(
            this,
            "Reservation could not be saved!"
    );

    return;
}
// Save each item in the reservation
for (String orderItem : currentOrder) {

    String[] parts = orderItem.split("\\|");

    // VALIDATION: order format
    if (parts.length < 2) {

        JOptionPane.showMessageDialog(
                this,
                "Invalid order data!"
        );

        return;
    }

    String itemText = parts[0].trim();
    int quantity;

    try {

        quantity = Integer.parseInt(
                parts[1].trim()
        );

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
                this,
                "Invalid quantity!"
        );

        return;
    }

    // VALIDATION: quantity
    if (quantity <= 0) {

        JOptionPane.showMessageDialog(
                this,
                "Quantity must be greater than 0!"
        );

        return;
    }

    String itemName;
    String variantName;

    // Check if item has a size/variant
    if (itemText.startsWith("Lumpia wrapper - ")) {

        itemName = "Lumpia wrapper";

        variantName =
                itemText.substring(
                        "Lumpia wrapper - ".length()
                ).trim();

    } else {

        itemName = itemText;
        variantName = "Regular";
    }

    // Get variant ID from MySQL
    int variantId =
            data.ItemDAO.getVariantId(
                    itemName,
                    variantName
            );

    // VALIDATION: variant must exist
    if (variantId <= 0) {

        JOptionPane.showMessageDialog(
                this,
                "Item variant not found:\n"
                + itemText
        );

        return;
    }

    // Get price from MySQL
    ArrayList<String> prices =
            data.ItemDAO.getPrices(itemName);

    double unitPrice = 0;

    for (String priceData : prices) {

        String[] priceParts =
                priceData.split("\\|");

        if (priceParts.length >= 2
                && priceParts[0].trim()
                        .equalsIgnoreCase(variantName)) {

            unitPrice =
                    Double.parseDouble(
                            priceParts[1].trim()
                    );

            break;
        }
    }

    // VALIDATION: price must exist
    if (unitPrice <= 0) {

        JOptionPane.showMessageDialog(
                this,
                "Price not found for:\n"
                + itemText
        );

        return;
    }

    // Save item to reservation_items
    boolean itemSaved =
            data.ReservationDAO.saveReservationItem(
                    reservationId,
                    variantId,
                    quantity,
                    unitPrice
            );

    // VALIDATION: item must be saved
   if (!itemSaved) {

    // Roll back the reservation and any
    // reservation items already saved.
    boolean rolledBack =
            data.ReservationDAO.rollbackReservation(
                    reservationId
            );

    if (rolledBack) {

        JOptionPane.showMessageDialog(
                this,
                "Could not save:\n"
                + itemText
                + "\n\nThe reservation was cancelled "
                + "because an item could not be saved."
        );

    } else {

        JOptionPane.showMessageDialog(
                this,
                "Could not save:\n"
                + itemText
                + "\n\nWARNING: The reservation could "
                + "not be rolled back."
        );
    }

    return;
}}
// Open PaymentGui
new PaymentGui(
        userName,
        currentOrder,
        reservationDate,
        reservationId
).setVisible(true); // TODO add your handling code here:
    }//GEN-LAST:event_btnReserveOrderActionPerformed

    private void btnReservationsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReservationsActionPerformed
        new ReservationGui(userName).setVisible(true);
    this.dispose();  // TODO add your handling code here:
    }//GEN-LAST:event_btnReservationsActionPerformed

    private void btnAboutUsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAboutUsActionPerformed
 JOptionPane.showMessageDialog(
            this,
            "🌿 GREEN GROCER\n\n"
            + "Your trusted neighborhood grocery reservation system.\n\n"
            + "SELLER INFORMATION\n"
            + "Name: Flora A. Acaso\n"
            + "Contact: 0975841064\n"
            + "Email: greengrocer@gmail.com\n"
            + "Address:Zone 2, Colanda, Iponan, CDO\n\n"
            + "Thank you for choosing Green Grocer!",
            "About Us",
            JOptionPane.INFORMATION_MESSAGE
    );        // TODO add your handling code here:
    }//GEN-LAST:event_btnAboutUsActionPerformed

    private void btnNeedHelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNeedHelpActionPerformed
      JOptionPane.showMessageDialog(
            this,
            "❓ HOW TO USE SARI SARI GROCER\n\n"
            + "1. CHOOSE AN ITEM\n"
            + "Click the product that you want to reserve.\n\n"
            
            + "2. ENTER QUANTITY\n"
            + "Enter the quantity you want.\n"
            + "Quantity must be greater than 0.\n\n"
            
            + "3. MY ORDER\n"
            + "View your selected items.\n"
            + "You can edit the quantity or remove an item.\n\n"
            
            + "4. RESERVE ORDER\n"
            + "Click Reserve Order to continue with your reservation.\n\n"
            
            + "5. MY RESERVATIONS\n"
            + "View your reservations and their current status.\n\n"
            
            + "6. PAYMENT\n"
            + "Follow the payment instructions shown by the system.\n\n"
            
            + "7. CANCELLATION\n"
            + "If cancellation is allowed, you can cancel your reservation.\n"
            + "A confirmation will appear before cancellation.",
            
            "NEED HELP",
            JOptionPane.INFORMATION_MESSAGE
    );  // TODO add your handling code here:
    }//GEN-LAST:event_btnNeedHelpActionPerformed

    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UserGUi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UserGUi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UserGUi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserGUi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserGUi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAboutUs;
    private javax.swing.JButton btnItem1;
    private javax.swing.JButton btnItem2;
    private javax.swing.JButton btnItem3;
    private javax.swing.JButton btnItem4;
    private javax.swing.JButton btnItem5;
    private javax.swing.JButton btnItem6;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnNeedHelp;
    private javax.swing.JButton btnReservation;
    private javax.swing.JButton btnReservations;
    private javax.swing.JButton btnReserveOrder;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JLabel lblTitle2;
    private javax.swing.JLabel lblTitle3;
    private javax.swing.JLabel lblWelcome;
    private javax.swing.JPanel pnlItems;
    // End of variables declaration//GEN-END:variables
}
