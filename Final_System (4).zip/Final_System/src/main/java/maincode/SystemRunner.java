/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maincode;

import java.util.ArrayList;
public class SystemRunner {
    
    
     
public static void main(String[] args) {

    new CustomerGui.LoginGui().setVisible(true);
}
}
